/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z44
 */

#ifndef ti_dsplib__
#define ti_dsplib__



#endif /* ti_dsplib__ */ 
